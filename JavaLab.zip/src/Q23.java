public class Q23
{
    public static void main(String[] args)
    {
        int[] myArray;          //declaration
        myArray = new int[5];   //instantiation
        myArray[0] = 10;        //initialization
        System.out.println("myArray[0] = " + myArray[0]);  //accessing and printing array elements
        System.out.println("myArray[1] = " + myArray[1]);
        int [] oddArray = {1,3,5,7};    //initialization with array literal
        System.out.println("oddArray[0] = " + oddArray[0]);
        System.out.println("oddArray[1] = " + oddArray[1]);
        System.out.println("oddArray[2] = " + oddArray[2]);
        System.out.println("oddArray[3] = " + oddArray[3]);
    }
}