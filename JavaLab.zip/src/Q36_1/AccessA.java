package Q36_1;

public class AccessA {
    //for default access modifier
    int number = 100;
    String country = "Nepal";

    //for public access modifier
    public int num = 99;
    public String flower = "Dandelion";

    //for private access modifier
    private int element = 1024;
    private String game = "football";

    //for protected access modifier
    protected int key = 22;
    protected  String animal = "Dog";
}
