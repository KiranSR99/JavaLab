
public class Q4 {
    public static void main(String[] args) {
        //Use of if statement
        if(20>10)
            System.out.println("20 is greater number.");


        //Use of if else statement
        int age = 20;
        if (age >= 18) {
            System.out.println("You can cast vote.");
        }
        else
            System.out.println("You can't cast vote.");


        //Use of ladder if statement
        int i=20;
        if(i==10)
            System.out.println("i is 10.");
        else if (i==15)
            System.out.println("i is 15.");
        else if(i==20)
            System.out.println("i is 20.");
        else
            System.out.println("i is not present.");

        //Use of nested if statement
        int a=100;
        int b=200;
        if(a==100)
            System.out.println("a is 100.");
        if (b==200)
            System.out.println("b is 200.");
    }

}
